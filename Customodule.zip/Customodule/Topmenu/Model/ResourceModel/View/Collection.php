<?php 
namespace Customodule\Topmenu\Model\ResourceModel\View;

use \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * Remittance File Collection Constructor
     * @return void
     */
    protected function _construct()
    {
        $this->_init(\Customodule\Topmenu\Model\View::class, \Customodule\Topmenu\Model\ResourceModel\View::class);
    }
}
?>