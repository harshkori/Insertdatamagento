<?php
namespace Customodule\Topmenu\Setup;

use Magento\Customer\Model\Customer;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\UpgradeDataInterface;
use Magento\Catalog\Model\Category;

class UpgradeData implements UpgradeDataInterface
{
    private $eavSetupFactory;
    
    private $eavConfig;
    
    private $attributeResource;
    
    public function __construct(
        \Magento\Eav\Setup\EavSetupFactory $eavSetupFactory,
        \Magento\Eav\Model\Config $eavConfig,
        \Magento\Customer\Model\ResourceModel\Attribute $attributeResource
    ) {
        $this->eavSetupFactory = $eavSetupFactory;
        $this->eavConfig = $eavConfig;
        $this->attributeResource = $attributeResource;
    }
    
    public function upgrade(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
        $entityTypeId = $eavSetup->getEntityTypeId(\Magento\Catalog\Model\Category::ENTITY);

        if (version_compare($context->getVersion(), '0.0.21') < 0)
        {


        $eavSetup->removeAttribute(Category::ENTITY, "custom_attribute");

        $attributeSetId = $eavSetup->getDefaultAttributeSetId(Category::ENTITY);
        $attributeGroupId = $eavSetup->getDefaultAttributeGroupId(Category::ENTITY);

        $eavSetup->addAttribute(Category::ENTITY, 'custom_attribute', [
            // Attribute parameters
                'type' => 'varchar',
                'label' => 'Category Custom field',
                'input' => 'textarea',
                'sort_order' => 100,
                'source' => '',
                'global' => 1,
                'visible' => true,
                'required' => false,
                'user_defined' => false,
                'default' => null,
                'group' => 'General Information',
                'backend' => '',
                'wysiwyg_enabled' => true,
                'is_html_allowed_on_front' => true




        ]);
    

        $installer->endSetup();

        // $attribute = $this->eavConfig->getAttribute(Category::ENTITY, 'erp_id');
        // $attribute->setData('attribute_set_id', $attributeSetId);
        // $attribute->setData('attribute_group_id', $attributeGroupId);

        
        // //You can use this attribute in the following forms
        // adminhtml_checkout
        // adminhtml_customer
        // adminhtml_customer_address
        // customer_account_create
        // customer_account_edit
        // customer_address_edit
        // customer_register_address
        

        // $attribute->setData('used_in_forms', [
        //     'adminhtml_customer',
        //     'customer_account_create',
        //     'customer_account_edit'
        // ]);

        // $this->attributeResource->save($attribute);
    }
    }
}
?>
