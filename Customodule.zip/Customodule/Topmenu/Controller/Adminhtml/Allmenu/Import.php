<?php
namespace Customodule\Topmenu\Controller\Adminhtml\Allmenu;
use Magento\MediaStorage\Model\File\UploaderFactory;
use Magento\Framework\Message\ManagerInterface;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\Filesystem;
// use Customodule\Extension\Model\ExtensionFactory;
use Customodule\Topmenu\Model\ViewFactory;


class Import extends \Magento\Backend\App\Action

{   
    protected $messageManager;
    protected $filesystem;
    protected $collectionFactory;

    protected $dir;

    protected $_pageFactory;
    protected $fileUploader;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $pageFactory,
        ManagerInterface $messageManager,
        Filesystem $filesystem,
        ResourceConnection $resourceConnection,
        UploaderFactory $fileUploader,
        ViewFactory $collectionFactory,
        \Magento\Framework\Filesystem\DirectoryList $dir

)
    {   
        $this->resourceConnection   =       $resourceConnection;
        $this->messageManager       =       $messageManager;
        $this->filesystem           =       $filesystem;
        $this->fileUploader         =       $fileUploader;
        $this->mediaDirectory       =       $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        $this->_pageFactory         =       $pageFactory;
        $this->collectionFactory    =       $collectionFactory;

        return parent::__construct($context);
    }

    public function execute()
    {
        
        $resultRender = $this->_pageFactory->create();
        $data = $this->getRequest()->getPostValue();
        if($data)
        {
            $id= $data['product_name'];
            $event=$this->collectionFactory->create();
            $event->setData($data);
            $event->save();
            $this->messageManager->addSuccess(__('Successfully saved the item.'));
        }
        return $resultRender;

    }

}




    